#!/usr/local/bin/dumb-init /bin/bash

set -e

# The whole configuration.yml can be mapped into the docker container, otherwise
# we fall back to filling in the default template from environment variables.
if [[ ! -f config/configuration.yml ]]; then
    envsubst < config/configuration-template.yml > config/configuration.yml
fi

exec "$@"
