-- *********************************************************************
-- Update to '8.3' Database Script
-- *********************************************************************
-- Change Log: META-INF/resourcesPrivate/com.symphonicsoft.db.cli/liquibase/symphonic-changelog.xml
-- Ran at: 11/10/19 17:56
-- Liquibase version: 3.7.0
-- *********************************************************************

-- Lock Database
UPDATE PUBLIC.DATABASECHANGELOGLOCK SET LOCKED = TRUE, LOCKEDBY = 'ip-172-17-0-1.eu-west-1.compute.internal (172.17.0.1)', LOCKGRANTED = '2019-10-11 17:56:43.218' WHERE ID = 1 AND LOCKED = FALSE;

-- Changeset META-INF/resourcesPrivate/com.symphonicsoft.db.cli/liquibase/8.2/modify-definition-table-parentId.xml::1::symphonic
ALTER TABLE PUBLIC.Definition ALTER COLUMN parentId VARCHAR(36);

INSERT INTO PUBLIC.DATABASECHANGELOG (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, CONTEXTS, LABELS, LIQUIBASE, DEPLOYMENT_ID) VALUES ('1', 'symphonic', 'META-INF/resourcesPrivate/com.symphonicsoft.db.cli/liquibase/8.2/modify-definition-table-parentId.xml', NOW(), 145, '8:f4aa8c74420c3a2746eda3e8a835385f', 'modifyDataType columnName=parentId, tableName=Definition', '', 'EXECUTED', NULL, NULL, '3.7.0', NULL);

-- Changeset META-INF/resourcesPrivate/com.symphonicsoft.db.cli/liquibase/8.2/changelog.xml::1::symphonic
INSERT INTO PUBLIC.DATABASECHANGELOG (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, CONTEXTS, LABELS, LIQUIBASE, DEPLOYMENT_ID, TAG) VALUES ('1', 'symphonic', 'META-INF/resourcesPrivate/com.symphonicsoft.db.cli/liquibase/8.2/changelog.xml', NOW(), 146, '8:c646a30b05282749a451e0cd02d86276', 'tagDatabase', '', 'EXECUTED', NULL, NULL, '3.7.0', NULL, '8.2');

-- Changeset META-INF/resourcesPrivate/com.symphonicsoft.db.cli/liquibase/8.3/add-constant-resolver-columns.xml::1::symphonic
ALTER TABLE PUBLIC.AttributeResolver ADD value CLOB;

INSERT INTO PUBLIC.DATABASECHANGELOG (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, CONTEXTS, LABELS, LIQUIBASE, DEPLOYMENT_ID) VALUES ('1', 'symphonic', 'META-INF/resourcesPrivate/com.symphonicsoft.db.cli/liquibase/8.3/add-constant-resolver-columns.xml', NOW(), 147, '8:3cf64fff68b2e57ff5df583ac5de509d', 'addColumn tableName=AttributeResolver', '', 'EXECUTED', NULL, NULL, '3.7.0', NULL);

-- Changeset META-INF/resourcesPrivate/com.symphonicsoft.db.cli/liquibase/8.3/add-constant-resolver-columns.xml::2::symphonic
ALTER TABLE PUBLIC.AttributeResolver ADD value_type VARCHAR(255);

INSERT INTO PUBLIC.DATABASECHANGELOG (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, CONTEXTS, LABELS, LIQUIBASE, DEPLOYMENT_ID) VALUES ('2', 'symphonic', 'META-INF/resourcesPrivate/com.symphonicsoft.db.cli/liquibase/8.3/add-constant-resolver-columns.xml', NOW(), 148, '8:1a2b672e2eff9566d84796afd95d3ddb', 'addColumn tableName=AttributeResolver', '', 'EXECUTED', NULL, NULL, '3.7.0', NULL);

-- Changeset META-INF/resourcesPrivate/com.symphonicsoft.db.cli/liquibase/8.3/changelog.xml::1::symphonic
INSERT INTO PUBLIC.DATABASECHANGELOG (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, CONTEXTS, LABELS, LIQUIBASE, DEPLOYMENT_ID, TAG) VALUES ('1', 'symphonic', 'META-INF/resourcesPrivate/com.symphonicsoft.db.cli/liquibase/8.3/changelog.xml', NOW(), 149, '8:f1f9c8cc3d0899e4040d6b185b086ea2', 'tagDatabase', '', 'EXECUTED', NULL, NULL, '3.7.0', NULL, '8.3');

-- Release Database Lock
UPDATE PUBLIC.DATABASECHANGELOGLOCK SET LOCKED = FALSE, LOCKEDBY = NULL, LOCKGRANTED = NULL WHERE ID = 1;
