-- *********************************************************************
-- Update to '8.4' Database Script
-- *********************************************************************
-- Change Log: META-INF/resourcesPrivate/com.symphonicsoft.db.cli/liquibase/symphonic-changelog.xml
-- Ran at: 08/11/19 16:48
-- Liquibase version: 3.7.0
-- *********************************************************************

-- Lock Database
UPDATE PUBLIC.DATABASECHANGELOGLOCK SET LOCKED = TRUE, LOCKEDBY = 'waleeds-mbp.lan (192.168.86.40)', LOCKGRANTED = '2019-11-08 16:48:18.965' WHERE ID = 1 AND LOCKED = FALSE;

-- Changeset META-INF/resourcesPrivate/com.symphonicsoft.db.cli/liquibase/8.4/add-deployment_package_approval-table.xml::1::symphonic
CREATE TABLE PUBLIC.deployment_package_approval (id BIGINT AUTO_INCREMENT NOT NULL, deployment_package_id VARCHAR(36) NOT NULL, user_id VARCHAR(1000) NOT NULL, date_approved TIMESTAMP DEFAULT NOW(), CONSTRAINT pk_deployment_package_approval PRIMARY KEY (id));

INSERT INTO PUBLIC.DATABASECHANGELOG (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, CONTEXTS, LABELS, LIQUIBASE, DEPLOYMENT_ID) VALUES ('1', 'symphonic', 'META-INF/resourcesPrivate/com.symphonicsoft.db.cli/liquibase/8.4/add-deployment_package_approval-table.xml', NOW(), 150, '8:829e3e2b869682d069467abb53c9a211', 'createTable tableName=deployment_package_approval', '', 'EXECUTED', NULL, NULL, '3.7.0', NULL);

-- Changeset META-INF/resourcesPrivate/com.symphonicsoft.db.cli/liquibase/8.4/add-deployment_package_approval-table.xml::2::symphonic
ALTER TABLE PUBLIC.deployment_package_approval ADD CONSTRAINT uq_deployment_package_approval_deployment_package_id_user_id UNIQUE (deployment_package_id, user_id);

INSERT INTO PUBLIC.DATABASECHANGELOG (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, CONTEXTS, LABELS, LIQUIBASE, DEPLOYMENT_ID) VALUES ('2', 'symphonic', 'META-INF/resourcesPrivate/com.symphonicsoft.db.cli/liquibase/8.4/add-deployment_package_approval-table.xml', NOW(), 151, '8:22602dbf7d59c1b230fe3b1f777da5b1', 'addUniqueConstraint constraintName=uq_deployment_package_approval_deployment_package_id_user_id, tableName=deployment_package_approval', '', 'EXECUTED', NULL, NULL, '3.7.0', NULL);

-- Changeset META-INF/resourcesPrivate/com.symphonicsoft.db.cli/liquibase/8.4/add-deployment_package_approval-table.xml::3::symphonic
ALTER TABLE PUBLIC.deployment_package_approval ADD CONSTRAINT fk_deployment_package_approval_deployment_package FOREIGN KEY (deployment_package_id) REFERENCES PUBLIC.DeploymentPackage (id) ON DELETE CASCADE;

INSERT INTO PUBLIC.DATABASECHANGELOG (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, CONTEXTS, LABELS, LIQUIBASE, DEPLOYMENT_ID) VALUES ('3', 'symphonic', 'META-INF/resourcesPrivate/com.symphonicsoft.db.cli/liquibase/8.4/add-deployment_package_approval-table.xml', NOW(), 152, '8:e39e7412ceb5fa04c840ece487a763f8', 'addForeignKeyConstraint baseTableName=deployment_package_approval, constraintName=fk_deployment_package_approval_deployment_package, referencedTableName=DeploymentPackage', '', 'EXECUTED', NULL, NULL, '3.7.0', NULL);

-- Changeset META-INF/resourcesPrivate/com.symphonicsoft.db.cli/liquibase/8.4/changelog.xml::1::symphonic
INSERT INTO PUBLIC.DATABASECHANGELOG (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, CONTEXTS, LABELS, LIQUIBASE, DEPLOYMENT_ID, TAG) VALUES ('1', 'symphonic', 'META-INF/resourcesPrivate/com.symphonicsoft.db.cli/liquibase/8.4/changelog.xml', NOW(), 153, '8:b87f3973525faccabdf1f68773c6c9c1', 'tagDatabase', '', 'EXECUTED', NULL, NULL, '3.7.0', NULL, '8.4');

-- Release Database Lock
UPDATE PUBLIC.DATABASECHANGELOGLOCK SET LOCKED = FALSE, LOCKEDBY = NULL, LOCKGRANTED = NULL WHERE ID = 1;
