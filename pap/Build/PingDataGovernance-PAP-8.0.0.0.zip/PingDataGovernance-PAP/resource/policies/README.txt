This directory contains default and example policy packages for
PingDataGovernance Server.

Policy file types
-----------------

*.SNAPSHOT
  A policy snapshot file, suitable for use in a development environment. This
  file can be loaded into the Symphonic Policy Administration GUI, which is used
  to manage policies and acts as a PDP when the Policy Decision Service is
  configured to use external PDP mode.

*.SDP
  A policy deployment package file, suitable for use in a production environment.
  This file can be loaded into the PingDataGovernance Server when the Policy
  Decision Service is configured to use embedded PDP mode.

Policy files
------------

defaultPolicies.*
  A minimal trust framework and policy set that should be used as a starting
  point for policy development.

gatewayPolicyExample.*
  An example policy set that demonstrates how to apply policies to an external
  REST API using the API Security Gateway.

scimPolicyExample.*
  An example policy set that demonstrates how to implement access token-based
  access control for the SCIM2 REST API.

Configuring embedded PDP mode
-----------------------------

Embedded PDP mode is configured via the Policy Decision Service in the
Administrative Console or dsconfig. The following example configures
PingDataGovernance Server to use the default policies deployment package in
embedded mode using dsconfig:

  dsconfig set-policy-decision-service-prop \
    --set pdp-mode:embedded \
    --set "deployment-package<resource/policies/defaultPolicies.SDP"
