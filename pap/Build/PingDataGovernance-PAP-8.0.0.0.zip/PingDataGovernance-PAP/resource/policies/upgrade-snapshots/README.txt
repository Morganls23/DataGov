This directory contains partial snapshots capable of upgrading the Trust
Framework of a policy deployment from one Ping DataGovernance version to another.

To use:
  1. After updating the Policy Administration GUI, select the branch you wish to upgrade.
  2. Go to Change Control, and click the Merge Snapshot tab.
  3. Select the correct partial snapshot, based on your current and target DataGoverance versions.
  4. Merge the partial snapshot.
  5. If any conflicts occur, select "Keep Snapshot's".